import turtle
import random

score = 0

wn = turtle.Screen()
wn.setup(610, 610)
wn.title("Muhammad Parvaiz - Turtle Game")
wn.bgcolor("#f5f8fc")

name = wn.textinput("Name", "Please enter your name:")

writer = turtle.Turtle(visible=False)
writer.penup()
writer.goto(-180, 255)
writer.write(f"Name: {name or 'Player'}", font=("Arial", 20, "bold"))

score_writer = turtle.Turtle(visible=False)
score_writer.penup()
score_writer.goto(150, 255)

player = turtle.Turtle()
player.shape("turtle")
player.color("blue")
player.penup()
player.speed(0)

target = turtle.Turtle()
target.shape("circle")
target.color("red")
target.penup()
target.speed(0)

border = turtle.Turtle(visible=False)
border.penup()
border.goto(-250, -250)
border.pendown()
for _ in range(4):
    border.forward(500)
    border.left(90)

def update_score():
    score_writer.clear()
    score_writer.write(f"Score: {score}", font=("Arial", 16, "bold"))

def move(dx, dy):
    x = player.xcor() + dx
    y = player.ycor() + dy
    if -235 <= x <= 235 and -235 <= y <= 235:
        player.goto(x, y)
    check_target()

def check_target():
    global score
    if player.distance(target) < 20:
        score += 1
        update_score()
        target.goto(random.randint(-225, 225), random.randint(-225, 225))

def up():
    move(0, 20)

def down():
    move(0, -20)

def left():
    move(-20, 0)

def right():
    move(20, 0)

wn.listen()
wn.onkeypress(up, "Up")
wn.onkeypress(down, "Down")
wn.onkeypress(left, "Left")
wn.onkeypress(right, "Right")

target.goto(random.randint(-225, 225), random.randint(-225, 225))
update_score()
wn.mainloop()
